<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-01 05:54:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp2h\htdocs\polesjambi\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-09-01 05:54:25 --> Unable to connect to the database
ERROR - 2021-09-01 05:54:25 --> Severity: Error --> Class 'CI_Controller' not found C:\xampp2h\htdocs\polesjambi\system\core\CodeIgniter.php 345
ERROR - 2021-09-01 05:54:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 05:54:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 05:54:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 05:54:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 05:54:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 08:25:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 08:25:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 08:25:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 08:25:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 08:25:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 08:27:03 --> Severity: Notice --> Undefined property: stdClass::$aktif C:\xampp2h\htdocs\polesjambi\application\controllers\List_booking.php 32
ERROR - 2021-09-01 08:27:03 --> Severity: Notice --> Undefined property: stdClass::$aktif C:\xampp2h\htdocs\polesjambi\application\controllers\List_booking.php 32
ERROR - 2021-09-01 08:27:28 --> Severity: Notice --> Undefined property: stdClass::$aktif C:\xampp2h\htdocs\polesjambi\application\controllers\List_booking.php 32
ERROR - 2021-09-01 08:27:28 --> Severity: Notice --> Undefined property: stdClass::$aktif C:\xampp2h\htdocs\polesjambi\application\controllers\List_booking.php 32
ERROR - 2021-09-01 08:29:25 --> Severity: Notice --> Undefined variable: id C:\xampp2h\htdocs\polesjambi\application\views\list_booking\list_booking_detail.php 130
ERROR - 2021-09-01 12:16:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 12:16:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 12:16:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 12:16:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 12:16:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 13:11:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 13:11:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 13:11:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 13:11:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 13:11:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-01 16:54:15 --> 404 Page Not Found: List-booking/assets
