<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-29 21:59:42 --> 404 Page Not Found: master_data/Mobil/merk_mobil
ERROR - 2021-08-29 22:00:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Merk_mobil_model C:\xampp2h\htdocs\polesjambi\system\core\Loader.php 348
ERROR - 2021-08-29 22:03:14 --> Severity: Notice --> Undefined property: Merk_mobil::$u_m C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 74
ERROR - 2021-08-29 22:03:14 --> Severity: Error --> Call to a member function getUser() on null C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 74
ERROR - 2021-08-29 22:03:23 --> Severity: Notice --> Undefined property: Merk_mobil::$u_m C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 74
ERROR - 2021-08-29 22:03:23 --> Severity: Error --> Call to a member function getUser() on null C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 74
ERROR - 2021-08-29 22:04:02 --> Severity: Notice --> Undefined property: Merk_mobil::$u_m C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 74
ERROR - 2021-08-29 22:04:02 --> Severity: Error --> Call to a member function getUser() on null C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 74
ERROR - 2021-08-29 22:05:42 --> 404 Page Not Found: cli/Generate/create_merk_mobil
ERROR - 2021-08-29 22:05:54 --> 404 Page Not Found: cli/Migrations/generate
ERROR - 2021-08-29 22:08:05 --> 404 Page Not Found: Defaults/blank
ERROR - 2021-08-29 22:08:28 --> 404 Page Not Found: Defaults/blank
ERROR - 2021-08-29 22:14:00 --> Severity: Notice --> Undefined property: Merk_mobil::$u_m C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 74
ERROR - 2021-08-29 22:14:00 --> Severity: Error --> Call to a member function getUser() on null C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 74
ERROR - 2021-08-29 22:14:21 --> Severity: Notice --> Undefined property: Merk_mobil::$u_m C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 74
ERROR - 2021-08-29 22:14:21 --> Severity: Error --> Call to a member function getUser() on null C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 74
ERROR - 2021-08-29 22:15:46 --> Severity: Notice --> Undefined property: Merk_mobil::$u_m C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 74
ERROR - 2021-08-29 22:15:46 --> Severity: Error --> Call to a member function getUser() on null C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 74
ERROR - 2021-08-29 22:25:21 --> Severity: Notice --> Undefined property: Merk_mobil::$ug_m C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 78
ERROR - 2021-08-29 22:25:21 --> Severity: Error --> Call to a member function getUserGroups() on null C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 78
