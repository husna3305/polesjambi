<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-31 07:17:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 07:17:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 07:17:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 07:17:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 07:17:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 07:41:22 --> 404 Page Not Found: List_booking/index
ERROR - 2021-08-31 07:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\helpers\my_helper.php 365
ERROR - 2021-08-31 07:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\helpers\my_helper.php 366
ERROR - 2021-08-31 07:42:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\helpers\my_helper.php 365
ERROR - 2021-08-31 07:42:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\helpers\my_helper.php 366
ERROR - 2021-08-31 07:52:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\helpers\my_helper.php 365
ERROR - 2021-08-31 07:52:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\helpers\my_helper.php 366
ERROR - 2021-08-31 07:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\helpers\my_helper.php 365
ERROR - 2021-08-31 07:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\helpers\my_helper.php 366
ERROR - 2021-08-31 07:53:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\helpers\my_helper.php 365
ERROR - 2021-08-31 07:53:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\helpers\my_helper.php 366
ERROR - 2021-08-31 08:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\helpers\my_helper.php 365
ERROR - 2021-08-31 08:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\helpers\my_helper.php 366
ERROR - 2021-08-31 09:02:14 --> 404 Page Not Found: Detail/index
ERROR - 2021-08-31 09:02:39 --> 404 Page Not Found: Detail/index
ERROR - 2021-08-31 09:03:23 --> 404 Page Not Found: Insert/index
ERROR - 2021-08-31 09:03:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'sSELECT slug FROM ms_menu WHERE slug='list-booking/' OR controller='list-booking' at line 1 - Invalid query: sSELECT slug FROM ms_menu WHERE slug='list-booking/' OR controller='list-booking/'
ERROR - 2021-08-31 09:04:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'sSELECT slug FROM ms_menu WHERE slug='list-booking/' OR controller='list-booking' at line 1 - Invalid query: sSELECT slug FROM ms_menu WHERE slug='list-booking/' OR controller='list-booking/'
ERROR - 2021-08-31 09:04:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'sSELECT slug FROM ms_menu WHERE slug='list-booking/' OR controller='list-booking' at line 1 - Invalid query: sSELECT slug FROM ms_menu WHERE slug='list-booking/' OR controller='list-booking/'
ERROR - 2021-08-31 09:05:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'sSELECT slug FROM ms_menu WHERE slug='list-booking' OR controller='list-booking'' at line 1 - Invalid query: sSELECT slug FROM ms_menu WHERE slug='list-booking' OR controller='list-booking'
ERROR - 2021-08-31 09:05:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'sSELECT slug FROM ms_menu WHERE slug='list-booking' OR controller='list-booking'' at line 1 - Invalid query: sSELECT slug FROM ms_menu WHERE slug='list-booking' OR controller='list-booking'
ERROR - 2021-08-31 09:07:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'w' at line 1 - Invalid query: SELECT slug FROM ms_menu WHERE slug='list_booking/fetchData' OR controller='list_booking/fetchData' w
ERROR - 2021-08-31 09:08:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'w' at line 1 - Invalid query: SELECT slug FROM ms_menu WHERE slug='list_booking/' OR controller='list_booking/' w
ERROR - 2021-08-31 09:08:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'w' at line 1 - Invalid query: SELECT slug FROM ms_menu WHERE slug='list_booking' OR controller='list_booking' w
ERROR - 2021-08-31 09:09:56 --> 404 Page Not Found: List-booking/detail
ERROR - 2021-08-31 09:10:52 --> 404 Page Not Found: List-booking/detail
ERROR - 2021-08-31 09:11:20 --> 404 Page Not Found: List-booking/detail
ERROR - 2021-08-31 09:11:21 --> 404 Page Not Found: List-booking/detail
ERROR - 2021-08-31 09:11:24 --> 404 Page Not Found: List-booking/detail
ERROR - 2021-08-31 09:11:49 --> 404 Page Not Found: List-booking/detail
ERROR - 2021-08-31 12:32:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 12:32:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 12:32:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 12:32:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 12:32:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 12:33:14 --> 404 Page Not Found: List-booking/insert
ERROR - 2021-08-31 15:41:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 15:41:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 15:41:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 15:41:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 15:41:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 17:31:57 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 17:31:57 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 17:31:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 17:31:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 17:31:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 17:42:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 17:42:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 17:42:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 17:42:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 17:42:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 23:56:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `id` = '71f5fujpj0rvkud395dbqnscl26vjape'' at line 2 - Invalid query: SELECT 1
WHERE `id` = '71f5fujpj0rvkud395dbqnscl26vjape'
ERROR - 2021-08-31 23:56:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `id` = '71f5fujpj0rvkud395dbqnscl26vjape'' at line 2 - Invalid query: SELECT 1
WHERE `id` = '71f5fujpj0rvkud395dbqnscl26vjape'
ERROR - 2021-08-31 23:56:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `id` = '71f5fujpj0rvkud395dbqnscl26vjape'' at line 2 - Invalid query: SELECT 1
WHERE `id` = '71f5fujpj0rvkud395dbqnscl26vjape'
ERROR - 2021-08-31 23:57:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `id` = '71f5fujpj0rvkud395dbqnscl26vjape'' at line 2 - Invalid query: SELECT 1
WHERE `id` = '71f5fujpj0rvkud395dbqnscl26vjape'
ERROR - 2021-08-31 23:57:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `id` = 'aod55m2sca772jct98n8ncr73vrgd22g'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'aod55m2sca772jct98n8ncr73vrgd22g'
ERROR - 2021-08-31 23:57:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `id` = 'mpu85ja4oic0pstgcasoa3u3etbfa0at'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'mpu85ja4oic0pstgcasoa3u3etbfa0at'
ERROR - 2021-08-31 23:57:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `id` = 'p9sfi57a0uit5has50ve3la402bb521t'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'p9sfi57a0uit5has50ve3la402bb521t'
ERROR - 2021-08-31 23:57:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `id` = '1rgpb8hsa6dj4qlnfl0a0h04qn8q78i0'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = '1rgpb8hsa6dj4qlnfl0a0h04qn8q78i0'
ERROR - 2021-08-31 23:58:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 23:58:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 23:58:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 23:58:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 23:58:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 23:58:55 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 23:58:55 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 23:58:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 23:58:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-31 23:58:56 --> 404 Page Not Found: Assets/images
