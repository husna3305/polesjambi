<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-06 06:12:39 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:39 --> 404 Page Not Found: Assets/vendor
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-06 06:12:39 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:39 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:39 --> 404 Page Not Found: Assets/css
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-06 06:12:39 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-06 06:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:13:33 --> 404 Page Not Found: Assets/frontassets
ERROR - 2021-09-06 06:19:19 --> 404 Page Not Found: Serviceshtml/index
ERROR - 2021-09-06 06:22:16 --> 404 Page Not Found: Front/css
ERROR - 2021-09-06 06:22:16 --> 404 Page Not Found: Front/fontawesome
ERROR - 2021-09-06 06:22:16 --> 404 Page Not Found: Front/css
ERROR - 2021-09-06 06:22:29 --> 404 Page Not Found: Front/fontawesome
ERROR - 2021-09-06 06:22:29 --> 404 Page Not Found: Front/css
ERROR - 2021-09-06 06:22:29 --> 404 Page Not Found: Front/css
ERROR - 2021-09-06 06:22:31 --> 404 Page Not Found: Front/fontawesome
ERROR - 2021-09-06 06:22:31 --> 404 Page Not Found: Front/css
ERROR - 2021-09-06 06:22:31 --> 404 Page Not Found: Front/css
ERROR - 2021-09-06 06:23:37 --> 404 Page Not Found: Asstes/front
ERROR - 2021-09-06 06:23:37 --> 404 Page Not Found: Asstes/front
ERROR - 2021-09-06 06:23:37 --> 404 Page Not Found: Asstes/front
ERROR - 2021-09-06 07:54:02 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-06 07:54:02 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-06 07:54:02 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-06 07:54:02 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-06 07:54:02 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-06 08:03:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp2h\htdocs\polesjambi\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-09-06 08:03:24 --> Unable to connect to the database
ERROR - 2021-09-06 08:03:24 --> Severity: Error --> Class 'CI_Controller' not found C:\xampp2h\htdocs\polesjambi\system\core\CodeIgniter.php 345
ERROR - 2021-09-06 08:04:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp2h\htdocs\polesjambi\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-09-06 08:04:10 --> Unable to connect to the database
ERROR - 2021-09-06 08:04:10 --> Severity: Error --> Class 'CI_Controller' not found C:\xampp2h\htdocs\polesjambi\system\core\CodeIgniter.php 345
ERROR - 2021-09-06 08:07:01 --> Severity: Notice --> Undefined variable: services C:\xampp2h\htdocs\polesjambi\application\views\front\services.php 94
ERROR - 2021-09-06 08:07:01 --> Severity: Notice --> Undefined variable: folder C:\xampp2h\htdocs\polesjambi\application\views\front\services.php 118
ERROR - 2021-09-06 08:07:01 --> Severity: Notice --> Undefined variable: file C:\xampp2h\htdocs\polesjambi\application\views\front\services.php 118
ERROR - 2021-09-06 08:07:04 --> Severity: Notice --> Undefined variable: services C:\xampp2h\htdocs\polesjambi\application\views\front\services.php 94
ERROR - 2021-09-06 08:07:04 --> Severity: Notice --> Undefined variable: folder C:\xampp2h\htdocs\polesjambi\application\views\front\services.php 118
ERROR - 2021-09-06 08:07:04 --> Severity: Notice --> Undefined variable: file C:\xampp2h\htdocs\polesjambi\application\views\front\services.php 118
ERROR - 2021-09-06 08:07:27 --> Severity: Notice --> Undefined variable: services C:\xampp2h\htdocs\polesjambi\application\views\front\services.php 94
ERROR - 2021-09-06 08:07:27 --> Severity: Notice --> Undefined variable: folder C:\xampp2h\htdocs\polesjambi\application\views\front\services.php 118
ERROR - 2021-09-06 08:07:27 --> Severity: Notice --> Undefined variable: file C:\xampp2h\htdocs\polesjambi\application\views\front\services.php 118
ERROR - 2021-09-06 08:08:12 --> Severity: Notice --> Undefined variable: folder C:\xampp2h\htdocs\polesjambi\application\views\front\services.php 118
ERROR - 2021-09-06 08:08:12 --> Severity: Notice --> Undefined variable: file C:\xampp2h\htdocs\polesjambi\application\views\front\services.php 118
ERROR - 2021-09-06 09:09:33 --> 404 Page Not Found: Front/booking.html
ERROR - 2021-09-06 10:33:42 --> Severity: Warning --> Illegal offset type C:\xampp2h\htdocs\polesjambi\application\controllers\Front.php 39
ERROR - 2021-09-06 10:33:52 --> Severity: Warning --> Illegal offset type C:\xampp2h\htdocs\polesjambi\application\controllers\Front.php 39
ERROR - 2021-09-06 10:35:22 --> Severity: Warning --> Illegal offset type C:\xampp2h\htdocs\polesjambi\application\controllers\Front.php 39
ERROR - 2021-09-06 10:35:43 --> Severity: Warning --> Illegal offset type C:\xampp2h\htdocs\polesjambi\application\controllers\Front.php 39
ERROR - 2021-09-06 10:39:49 --> 404 Page Not Found: Assets/front
ERROR - 2021-09-06 10:40:11 --> 404 Page Not Found: Assets/front
ERROR - 2021-09-06 10:46:58 --> Severity: Parsing Error --> syntax error, unexpected ']' C:\xampp2h\htdocs\polesjambi\application\controllers\Front.php 44
ERROR - 2021-09-06 10:47:08 --> Severity: Notice --> Undefined index: NU5oIaLEnqx3QReAIecI6JhpB6O7hxFQKL91518DUZWajVryRws C:\xampp2h\htdocs\polesjambi\application\controllers\Front.php 41
ERROR - 2021-09-06 10:49:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'sAND mu.id_services IN ('2','3')' at line 3 - Invalid query: SELECT id_services,judul,((SELECT gambar_small FROM ms_services_gambar WHERE id_services=mu.id_services AND utama=1 ORDER BY created_at DESC LIMIT 1)) gambar_small,estimasi_biaya,estimasi_waktu_menit,estimasi_waktu_jam,0 dipilih
    FROM ms_services AS mu
    WHERE 1=1 sAND mu.id_services IN ('2','3')
    
    
    
ERROR - 2021-09-06 10:49:19 --> 404 Page Not Found: Front/css
ERROR - 2021-09-06 10:49:19 --> 404 Page Not Found: Front/css
ERROR - 2021-09-06 10:49:25 --> 404 Page Not Found: Front/assets
ERROR - 2021-09-06 10:49:28 --> 404 Page Not Found: Front/css
ERROR - 2021-09-06 10:49:28 --> 404 Page Not Found: Front/css
ERROR - 2021-09-06 10:49:30 --> 404 Page Not Found: Front/assets
ERROR - 2021-09-06 10:50:21 --> 404 Page Not Found: Front/assets
ERROR - 2021-09-06 12:40:45 --> 404 Page Not Found: cli/Migration/index
ERROR - 2021-09-06 12:40:53 --> Query error: Incorrect table definition; there can be only one auto column and it must be defined as a key - Invalid query: CREATE TABLE `booking` (
	`id_booking` VARCHAR(20) NOT NULL,
	`no_polisi` VARCHAR(50) NOT NULL,
	`nama_barang` VARCHAR(50) NOT NULL,
	`no_wa` VARCHAR(20) NOT NULL,
	`id_merk_mobil` INT(3) UNSIGNED NOT NULL,
	`id_jenis_mobil` INT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
	`tanggal_booking` DATE NOT NULL,
	`jam_booking` TIME NOT NULL,
	`alamat` VARCHAR(250) NULL,
	`provinsi_id` VARCHAR(2) NULL,
	`kabupaten_id` VARCHAR(4) NULL,
	`kecamatan_id` VARCHAR(7) NULL,
	`kelurahan_id` VARCHAR(10) NULL,
	`status` VARCHAR(30) NULL,
	`created_at` DATETIME NOT NULL,
	`created_by` INT(8) UNSIGNED NOT NULL,
	`updated_at` DATETIME NULL,
	`updated_by` INT(8) UNSIGNED NULL,
	CONSTRAINT `pk_booking` PRIMARY KEY(`id_booking`)
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2021-09-06 13:25:58 --> Query error: Table 'db_polesjambi.booking' doesn't exist - Invalid query: SELECT RIGHT(id_booking,3) id_booking FROM booking 
                  ORDER BY id_booking,created_at DESC LIMIT 0,1
ERROR - 2021-09-06 13:27:06 --> Severity: Notice --> Array to string conversion C:\xampp2h\htdocs\polesjambi\application\models\Services_model.php 36
ERROR - 2021-09-06 13:27:06 --> Severity: Notice --> Array to string conversion C:\xampp2h\htdocs\polesjambi\application\controllers\Front.php 82
ERROR - 2021-09-06 13:28:02 --> Severity: Notice --> Undefined index: id_services C:\xampp2h\htdocs\polesjambi\application\controllers\Front.php 78
ERROR - 2021-09-06 13:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp2h\htdocs\polesjambi\application\controllers\Front.php 78
ERROR - 2021-09-06 13:38:22 --> Query error: Unknown column 'nama_lengkap' in 'field list' - Invalid query: INSERT INTO `booking` (`id_booking`, `no_polisi`, `nama_lengkap`, `no_wa`, `id_merk_mobil`, `id_jenis_mobil`, `tanggal_booking`, `jam_booking`, `alamat`, `provinsi_id`, `kabupaten_id`, `kecamatan_id`, `kelurahan_id`, `created_at`, `created_by`) VALUES ('210906001', 'Voluptas quae labore', 'Voluptate est quis l', 'Qui sit est suscipit', NULL, NULL, '01-Jan-1973', '13:20', 'Consequatur Omnis v', '15', '1501', 'Pilih', 'Pilih', '2021-09-06 13:38:22', 0)
ERROR - 2021-09-06 13:39:04 --> Query error: Column 'id_merk_mobil' cannot be null - Invalid query: INSERT INTO `booking` (`id_booking`, `no_polisi`, `nama_lengkap`, `no_wa`, `id_merk_mobil`, `id_jenis_mobil`, `tanggal_booking`, `jam_booking`, `alamat`, `provinsi_id`, `kabupaten_id`, `kecamatan_id`, `kelurahan_id`, `created_at`, `created_by`) VALUES ('210906001', 'Voluptas quae labore', 'Voluptate est quis l', 'Qui sit est suscipit', NULL, NULL, '01-Jan-1973', '13:20', 'Consequatur Omnis v', '15', '1501', 'Pilih', 'Pilih', '2021-09-06 13:39:04', 0)
ERROR - 2021-09-06 13:39:37 --> 404 Page Not Found: Front/undefined
ERROR - 2021-09-06 13:42:08 --> Severity: Notice --> Undefined index: id_booking C:\xampp2h\htdocs\polesjambi\application\controllers\Front.php 118
ERROR - 2021-09-06 13:43:40 --> Query error: Unknown column 'mu.id_booking' in 'where clause' - Invalid query: SELECT book.*
    FROM booking AS book
    WHERE 1=1 AND mu.id_booking='210906002'
    
    
    
ERROR - 2021-09-06 13:46:36 --> Query error: Table 'db_polesjambi.ms_provinsi' doesn't exist - Invalid query: SELECT book.*,merk.merk_mobil,jenis.jenis_mobil,provinsi,kabupaten,kecamatan,kelurahan
    FROM booking AS book
    JOIN ms_merk_mobil merk ON merk.id_merk_mobil=book.id_merk_mobil
    JOIN ms_jenis_mobil jenis ON jenis.id_jenis_mobil=book.id_jenis_mobil
    LEFT JOIN ms_provinsi prov ON prov.provinsi_id=book.provinsi_id
    LEFT JOIN ms_kabupaten kab ON kab.kabupaten_id=book.kabupaten_id
    LEFT JOIN ms_kecamatan kec ON kec.kecamatan_id=book.kecamatan_id
    LEFT JOIN ms_kelurahan kel ON kel.kelurahan_id=book.kelurahan_id
    WHERE 1=1 AND book.id_booking='210906002'
    
    
    
ERROR - 2021-09-06 13:48:54 --> 404 Page Not Found: Front/assets
ERROR - 2021-09-06 13:48:57 --> 404 Page Not Found: Front/assets
ERROR - 2021-09-06 13:50:19 --> 404 Page Not Found: Front/assets
ERROR - 2021-09-06 14:00:31 --> Query error: Table 'db_polesjambi.booking' doesn't exist - Invalid query: SELECT RIGHT(id_booking,3) id_booking FROM booking 
                  ORDER BY id_booking,created_at DESC LIMIT 0,1
ERROR - 2021-09-06 14:08:08 --> Severity: Warning --> rand() expects exactly 2 parameters, 1 given C:\xampp2h\htdocs\polesjambi\application\controllers\Front.php 94
