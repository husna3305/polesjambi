<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-30 06:46:04 --> Query error: Unknown column 'created' in 'field list' - Invalid query: INSERT INTO `ms_merk_mobil` (`merk_mobil`, `aktif`, `created`, `created_by`) VALUES ('Toyota', 1, '2021-08-30 06:46:04', '1')
ERROR - 2021-08-30 06:46:27 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 29
ERROR - 2021-08-30 06:48:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'sSELECT link,akses FROM ms_menu mn
						LEFT JOIN ms_user_groups_role rl ON mn.' at line 1 - Invalid query: sSELECT link,akses FROM ms_menu mn
						LEFT JOIN ms_user_groups_role rl ON mn.id_menu=rl.id_menu
						WHERE (mn.slug='master-data/merk-mobil' OR mn.controller='master-data/merk-mobil') 
ERROR - 2021-08-30 06:52:18 --> 404 Page Not Found: Master-data/sounds
ERROR - 2021-08-30 06:55:58 --> Severity: Notice --> Undefined property: Merk_mobil::$u_m C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 118
ERROR - 2021-08-30 06:55:58 --> Severity: Error --> Call to a member function getUser() on null C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 118
ERROR - 2021-08-30 09:11:56 --> Severity: Notice --> Undefined property: Merk_mobil::$u_m C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 174
ERROR - 2021-08-30 09:11:56 --> Severity: Error --> Call to a member function getUser() on null C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Merk_mobil.php 174
ERROR - 2021-08-30 10:48:03 --> 404 Page Not Found: Master-data/merk-mobil
ERROR - 2021-08-30 10:48:05 --> 404 Page Not Found: Master-data/merk-mobil
ERROR - 2021-08-30 10:54:11 --> 404 Page Not Found: master_data/Provinsi/index
ERROR - 2021-08-30 10:58:11 --> 404 Page Not Found: master_data/Services/index
ERROR - 2021-08-30 11:07:14 --> 404 Page Not Found: master_data/Provinsi/index
ERROR - 2021-08-30 11:24:41 --> 404 Page Not Found: Setting/index
ERROR - 2021-08-30 11:25:02 --> 404 Page Not Found: master_data/Services/index
ERROR - 2021-08-30 11:29:22 --> 404 Page Not Found: Setting/index
ERROR - 2021-08-30 11:44:53 --> 404 Page Not Found: master_data/Services/index
ERROR - 2021-08-30 11:56:57 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 11:57:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 12:00:34 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 12:00:34 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 12:00:34 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 12:00:34 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 12:00:34 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 12:01:52 --> 404 Page Not Found: master_data/Services/index
ERROR - 2021-08-30 12:01:58 --> 404 Page Not Found: master_data/Provinsi/index
ERROR - 2021-08-30 12:07:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 12:07:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 12:07:29 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 12:07:29 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 12:07:29 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 12:07:36 --> 404 Page Not Found: master_data/Hari_libur/index
ERROR - 2021-08-30 13:34:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 13:34:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 13:34:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 13:34:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 13:34:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 18:49:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 18:49:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 18:49:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 18:49:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 18:49:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 18:54:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 18:54:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 18:54:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 18:54:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 18:54:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:04:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:04:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:04:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:04:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:04:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:13:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:13:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:13:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:13:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:13:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:17:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:17:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:17:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:17:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 22:17:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 23:07:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 23:07:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 23:07:19 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 23:07:19 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 23:07:19 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-30 23:40:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Provinsi.php 29
ERROR - 2021-08-30 23:40:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Provinsi.php 32
ERROR - 2021-08-30 23:40:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Provinsi.php 38
ERROR - 2021-08-30 23:55:32 --> Severity: Notice --> Undefined property: stdClass::$merek_mobil C:\xampp2h\htdocs\polesjambi\application\controllers\master_data\Jenis_mobil.php 39
ERROR - 2021-08-30 23:59:03 --> 404 Page Not Found: master_data/Services/index
