<!--start page wrapper -->
<div class="page-wrapper">
	<div class="page-content"></div>
</div>