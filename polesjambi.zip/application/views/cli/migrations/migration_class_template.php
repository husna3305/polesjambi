defined('BASEPATH') or exit('No direct script access allowed');

class Migration_<?= $className ?> extends CI_Migration
{
    public function up()
    {
        
    }

    public function down()
    {
        
    }
}